#define MR_SHORTHAND
#import <CoreData+MagicalRecord.h>